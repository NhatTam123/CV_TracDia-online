function showContact() {
  const form = document.getElementById("contact-form");
  form.style.display = form.style.display === "none" ? "block" : "none";
}